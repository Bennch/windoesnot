/* nautilus-batch-rename-utilities.c
 *
 * Copyright (C) 2016 Alexandru Pandelea <alexandru.pandelea@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#pragma once

#include <gio/gio.h>
#include <gtk/gtk.h>

GList* batch_rename_dialog_get_new_names_list          (NautilusBatchRenameDialogMode  mode,
                                                        GList                         *selection,
                                                        GList                         *tags_list,
                                                        GHashTable                    *selection_metadata,
                                                        gchar                         *entry_text,
                                                        gchar                         *replace_text);

GList* nautilus_batch_rename_dialog_sort        (GList                       *selection,
                                                 SortMode                     mode,
                                                 GHashTable                  *creation_date_table);

void check_metadata_for_selection               (NautilusBatchRenameDialog *dialog,
                                                 GList                     *selection,
                                                 GCancellable              *cancellable);

void string_free                                (gpointer mem);

void conflict_data_free                         (gpointer mem);

GList* batch_rename_files_get_distinct_parents  (GList *selection);

gboolean file_name_conflicts_with_results       (GList        *selection,
                                                 GList        *new_names,
                                                 GString      *old_name,
                                                 gchar        *parent_uri);

GString* markup_hightlight_text                 (const char  *label,
                                                 const gchar *substring,
                                                 const gchar *replacement_text,
                                                 const gchar *text_color,
                                                 const gchar *background_color);

const gchar* batch_rename_get_tag_text_representation (TagConstants tag_constants);
